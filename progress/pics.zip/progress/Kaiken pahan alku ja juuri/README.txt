Kun l�hdin tekem��n projektia, ajattelin, ett� projektio hoitaisi kameran liikkumisen maailmassa, 
kuin my�s k��ntymisen. Kahdessa kuvassa on eroa sen virheen verran, joka maksoi kymmeni� tunteja,
ja monta erilaista fiksausyrityst�, jotka kukin johtivat seuraavien ratkaisemisen vaikeutumiseen,
ennen kuin viimein huomasin kohtalokkaan virheeni.
